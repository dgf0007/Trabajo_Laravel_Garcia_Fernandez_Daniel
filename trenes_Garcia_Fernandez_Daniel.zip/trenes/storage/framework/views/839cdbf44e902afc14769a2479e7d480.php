<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ticket Index</title>
    <!-- Agrega la referencia al archivo CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-primary">Crear ticket</a>
        <table class="table mt-3">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Precio</th>
                    <th>Nombre del tren</th>
                    <th>Tipo de ticket</th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($ticket->date); ?></td>
                        <td><?php echo e($ticket->price); ?></td>
                        <td><?php echo e($ticket->train->name); ?></td>
                        <td><?php echo e($ticket->ticket_type->type); ?></td>
                        <td>
                            <form action="<?php echo e(route('tickets.show', ['ticket' => $ticket->id])); ?>">
                                <button type="submit" class="btn btn-success">Ver</button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(route('tickets.edit', ['ticket' => $ticket->id])); ?>" method="get">
                                <button type="submit" class="btn btn-warning">Editar</button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(route('tickets.destroy', ['ticket' => $ticket->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-danger">Borrar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\trenes\resources\views/tickets/index.blade.php ENDPATH**/ ?>