<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Ticket</title>
    <!-- Agrega la referencia al archivo CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <form action="<?php echo e(route('tickets.update', ['ticket' => $ticket->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>


            <div class="mb-3">
                <label for="date" class="form-label">Fecha</label>
                <input type="date" class="form-control" name="date" value="<?php echo e($ticket->date); ?>">
            </div>

            <div class="mb-3">
                <label for="price" class="form-label">Precio</label>
                <input type="number" class="form-control" name="price" value="<?php echo e($ticket->price); ?>">
            </div>

            <div class="mb-3">
                <label for="train_name" class="form-label">Nombre del tren</label>
                <select class="form-select" name="train_name">
                    <option selected hidden value="<?php echo e($ticket->train->id); ?>"><?php echo e($ticket->train->name); ?></option>
                    <?php $__currentLoopData = $trains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($train->id); ?>"><?php echo e($train->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="ticket_type_id" class="form-label">Tipo de ticket</label>
                <select class="form-select" name="ticket_type_id">
                    <option selected hidden value="<?php echo e($ticket->ticket_type->id); ?>"><?php echo e($ticket->ticket_type->type); ?></option>
                    <?php $__currentLoopData = $ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticketType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ticketType->id); ?>"><?php echo e($ticketType->type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Editar</button>
        </form>
    </div>

    <!-- Agrega los archivos JavaScript de Bootstrap para funcionalidades adicionales (opcional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\trenes\resources\views/tickets/edit.blade.php ENDPATH**/ ?>